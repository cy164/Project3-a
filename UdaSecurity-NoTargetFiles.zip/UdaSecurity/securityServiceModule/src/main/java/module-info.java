module com.udacity.catpoint.securityService {
    requires java.desktop;
    requires java.prefs;
    requires com.google.common;
    requires com.google.gson;
    requires com.udacity.catpoint.imageService;
    requires miglayout.swing;
    opens com.udacity.catpoint.securityService.data to com.google.gson;
}