package com.udacity.catpoint.securityService.service;

import com.udacity.catpoint.imageService.service.FakeImageServiceImpl;
import com.udacity.catpoint.securityService.application.CatpointGui;
import com.udacity.catpoint.securityService.data.*;
import com.udacity.catpoint.securityService.service.SecurityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyFloat;
import static org.mockito.Mockito.when;

/**
 * Unit test for simple App.
 */
@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest
{
    private CatpointGui catpointGui;
    private SecurityService securityService;
    private SecurityRepository securityRepository;

    @Mock
    private FakeImageServiceImpl fakeImageService;
    //private AwsImageService awsImageService;
    //private ImageService imageService;

    @BeforeEach
    void init() {
        securityRepository = new PretendDatabaseSecurityRepositoryImpl();
        //fakeImageService = new FakeImageServiceImpl();
        //awsImageService = new AwsImageService();
        securityService = new SecurityService(securityRepository, fakeImageService);
        Set<Sensor> sensors = securityService.getSensors();
        if(sensors.size() < 2) {
            Sensor sensor1 = new Sensor("FrontDoor", SensorType.DOOR);
            Sensor sensor2 = new Sensor("Window", SensorType.WINDOW);

            securityService.addSensor(sensor1);
            securityService.addSensor(sensor2);
        }
        else {
            //Set<Sensor> sensors = securityService.getSensors();
            //Sensor[] sensorArray = sensors.toArray(new Sensor[sensors.size()]);
            //securityService.changeSensorActivationStatus(sensorArray[0], false);
            //securityService.changeSensorActivationStatus(sensorArray[1], false);
            for(Sensor sensor : sensors) {
                securityService.changeSensorActivationStatus(sensor, false);
            }
        }
        securityService.setArmingStatus(ArmingStatus.DISARMED);
    }

    /*@CsvSource({
            "ArmingStatus.ARMED_AWAY, AlarmStatus.NO_ALARM, AlarmStatus.PENDING_ALARM",
            "ArmingStatus.ARMED_HOME, AlarmStatus.NO_ALARM, AlarmStatus.PENDING_ALARM",
            "ArmingStatus.ARMED_AWAY, AlarmStatus.PENDING_ALARM, AlarmStatus.ALARM",
            "ArmingStatus.ARMED_HOME, AlarmStatus.PENDING_ALARM, AlarmStatus.ALARM",
    })*/
    /**
     * Rigorous Test :-)
     */

    // test for unit test item 1, 2, 3, 4, 5, 6
    @ParameterizedTest
    @MethodSource("setAlarmStatus_arguments")
    public void setAlarmStatus_alarmArmedAndSensorActivated_putSystemIntoPendingStatus(
            ArmingStatus armingStatus,
            AlarmStatus alarmStatus,
            boolean bSensor1Activated, boolean bSensor2Activated,
            AlarmStatus expectedAlarmStatus) {
        //Sensor sensor1 = new Sensor("FrontDoor", SensorType.DOOR);
        //Sensor sensor2 = new Sensor("Window", SensorType.WINDOW);

        securityService.setArmingStatus(armingStatus);
        securityService.setAlarmStatus(alarmStatus);
        // activate or deactivate sensor(s)
        Set<Sensor> sensors = securityService.getSensors();
        Sensor[] sensorArray = sensors.toArray(new Sensor[sensors.size()]);
        securityService.changeSensorActivationStatus(sensorArray[0], bSensor1Activated);
        securityService.changeSensorActivationStatus(sensorArray[1], bSensor2Activated);

        assertEquals(expectedAlarmStatus, securityService.getAlarmStatus());
    }

    // arguments for unit test item 1, 2, 3, 4, 5, 6
    private static Stream<Arguments> setAlarmStatus_arguments() {
        return Stream.of(
                // item 1 arguments
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.NO_ALARM, true, false, AlarmStatus.PENDING_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.NO_ALARM, true, false, AlarmStatus.PENDING_ALARM),
                // item 2 arguments
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.PENDING_ALARM, true, true, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.PENDING_ALARM, true, true, AlarmStatus.ALARM),
                // item 3 arguments (failing test)
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.PENDING_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.PENDING_ALARM, false, false, AlarmStatus.NO_ALARM),
                // item 4 arguments
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.ALARM, false, false, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.ALARM, false, false, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.ALARM, true, false, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.ALARM, true, false, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.ALARM, true, true, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.ALARM, true, true, AlarmStatus.ALARM),
                // item 5 arguments
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.PENDING_ALARM, true, true, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.PENDING_ALARM, true, true, AlarmStatus.ALARM),
                // item 6 arguments
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.NO_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.NO_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.ALARM, false, false, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.ALARM, false, false, AlarmStatus.ALARM)
                // additional test for code coverage

        );
    }

    // test item 7:
    // If the image service identifies an image containing a cat while the system is armed-home,
    // put the system into alarm status.
    @Test
    public void imageContainsCat_systemArmed_putSystemIntoAlarm() {
        //boolean imageContainsCat(BufferedImage image, float confidenceThreshhold);
        // new File("c:\\test\\image.png")
        //String dir = System.getProperty("user.dir");
        BufferedImage currentCameraImage = null;
        String fileName = "../imageServiceModule/sample-cat.jpg";

        try {
            currentCameraImage = ImageIO.read(new File(fileName));
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        when(fakeImageService.imageContainsCat(any(BufferedImage.class), anyFloat())).thenReturn(true);

        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        //boolean bResult = fakeImageService.imageContainsCat(currentCameraImage, 50.0f);
        securityService.processImage(currentCameraImage);
        AlarmStatus alarmStatus = securityService.getAlarmStatus();
        assertEquals(alarmStatus, AlarmStatus.ALARM);
    }

    // test item 8:
    // If the image service identifies an image that does not contain a cat,
    // change the status to no alarm as long as the sensors are not active.
    @ParameterizedTest
    @MethodSource("setImageContainNoCat_arguments")
    public void imageContainsNoCat_systemArmed_sensorsActiveOrNot_AlarmStatusChangeOrNot(
            ArmingStatus armingStatus,
            AlarmStatus initialAlarmStatus,
            boolean bSensor1Activated, boolean bSensor2Activated,
            AlarmStatus expectedAlarmStatus) {

        BufferedImage currentCameraImage = null;
        String fileName = "../imageServiceModule/sample-not-cat.jpg";

        try {
            currentCameraImage = ImageIO.read(new File(fileName));
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        when(fakeImageService.imageContainsCat(any(BufferedImage.class), anyFloat())).thenReturn(false);
        securityService.setAlarmStatus(initialAlarmStatus);
        ArmingStatus status = securityService.getArmingStatus();
        securityService.setArmingStatus(armingStatus);

        /*Sensor sensor1 = new Sensor("FrontDoor", SensorType.DOOR);
        Sensor sensor2 = new Sensor("Window", SensorType.WINDOW);
        // deactivate sensor(s)
        securityService.changeSensorActivationStatus(sensor1, false);
        securityService.changeSensorActivationStatus(sensor2, false);*/
        // activate sensor(s)
        Set<Sensor> sensors = securityService.getSensors();
        Sensor[] sensorArray = sensors.toArray(new Sensor[sensors.size()]);
        securityService.changeSensorActivationStatus(sensorArray[0], bSensor1Activated);
        securityService.changeSensorActivationStatus(sensorArray[1], bSensor2Activated);

        //boolean bResult = fakeImageService.imageContainsCat(currentCameraImage, 50.0f);
        securityService.processImage(currentCameraImage);

        AlarmStatus alarmStatus = securityService.getAlarmStatus();
        assertEquals(expectedAlarmStatus, alarmStatus);
    }

    private static Stream<Arguments> setImageContainNoCat_arguments() {
        return Stream.of(
                // test item 8 arguments
                Arguments.of(ArmingStatus.DISARMED, AlarmStatus.NO_ALARM, true, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.NO_ALARM, true, false, AlarmStatus.PENDING_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.PENDING_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_AWAY, AlarmStatus.PENDING_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.NO_ALARM, false, true, AlarmStatus.PENDING_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.ARMED_HOME, AlarmStatus.ALARM, true, true, AlarmStatus.ALARM),
                Arguments.of(ArmingStatus.DISARMED, AlarmStatus.NO_ALARM, false, false, AlarmStatus.NO_ALARM),
                Arguments.of(ArmingStatus.DISARMED, AlarmStatus.NO_ALARM, true, false, AlarmStatus.NO_ALARM)
        );
    }

    // test for unit test item 9
    // If the system is disarmed, set the status to no alarm.
    @Test
    public void setArmingStatusToDisarmed_checkAlarmAndArmingStatus() {
        // AlarmStatus should return NO_ALARM
        // ArmingStatus should return DISARMED
        securityService.setArmingStatus(ArmingStatus.DISARMED);
        ArmingStatus armingStatus = securityService.getArmingStatus();
        AlarmStatus alarmStatus = securityService.getAlarmStatus();

        assertEquals(ArmingStatus.DISARMED, armingStatus);
        assertEquals(AlarmStatus.NO_ALARM, alarmStatus);
    }

    // test item 10:
    // If the system is armed, reset all sensors to inactive. initially disarmed
    @ParameterizedTest
    @MethodSource("setSystemIsArmed_arguments")
    public void systemIsArmed_ResetAllSensors(
            ArmingStatus armingStatus,
            boolean bSensor1Activated, boolean bSensor2Activated) {
        Set<Sensor> sensors = securityService.getSensors();
        Sensor[] sensorArray = sensors.toArray(new Sensor[sensors.size()]);
        securityService.changeSensorActivationStatus(sensorArray[0], bSensor1Activated);
        securityService.changeSensorActivationStatus(sensorArray[1], bSensor2Activated);

        securityService.setArmingStatus(ArmingStatus.DISARMED);
        securityService.setArmingStatus(armingStatus);

        boolean bSensorsActive = false;
        //Set<Sensor> sensors = securityService.getSensors();
        for (Sensor sensor : sensors) {
            if (sensor.getActive()) {
                bSensorsActive = true;
                break;
            }
        }
        assertEquals(false, bSensorsActive);
    }

    private static Stream<Arguments> setSystemIsArmed_arguments() {
        return Stream.of(
                // test item 8 arguments
                Arguments.of(ArmingStatus.ARMED_HOME, true, true),
                Arguments.of(ArmingStatus.ARMED_AWAY, true, true),
                Arguments.of(ArmingStatus.ARMED_HOME, false, false),
                Arguments.of(ArmingStatus.ARMED_AWAY, false, false)
        );
    }

    // test item 11:
    // If the image service identifies an image containing a cat while the system is armed-home,
    // put the system into alarm status.
    @Test
    public void cameraShowsCat_systemArmed_putSystemIntoAlarm() {
        //boolean imageContainsCat(BufferedImage image, float confidenceThreshhold);
        // new File("c:\\test\\image.png")
        //String dir = System.getProperty("user.dir");
        BufferedImage currentCameraImage = null;
        String fileName = "../imageServiceModule/sample-cat.jpg";

        try {
            currentCameraImage = ImageIO.read(new File(fileName));
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        when(fakeImageService.imageContainsCat(any(BufferedImage.class), anyFloat())).thenReturn(true);

        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
        securityService.processImage(currentCameraImage);
        AlarmStatus alarmStatus = securityService.getAlarmStatus();
        assertEquals(AlarmStatus.ALARM, alarmStatus);
    }
}
